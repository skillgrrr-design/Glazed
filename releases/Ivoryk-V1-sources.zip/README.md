Ivoryk Client

Instalación

1. Descarga Meteor Client desde https://meteorclient.com/ y colócalo en la carpeta `mods` de tu instalación de Minecraft (junto con Fabric Loader).
2. Compila o descarga este addon y coloca su archivo `.jar` en la misma carpeta `mods`.
3. Inicia Minecraft con el perfil de Fabric y abre Meteor Client con Right Shift.

Qué se agregó

- TriggerBot: ataca entidades configurables al apuntarlas.
- AimAssist: asistente de apuntado con opciones de suavizado y FOV.
- NoSlow: evita ralentizaciones al comer
- AutoGG: envía un mensaje personalizado tras matar a un jugador (texto editable y delay).

Notas

- El cliente ahora aparece como "Ivoryk" en la categoría del addon.
- Se intentó mantener compatibilidad con Meteor Client 1.21.4 y con módulos opcionales (usando reflection cuando fue necesario).

Licencia

Proyecto abierto, úsalo bajo tu propia responsabilidad.
